# Coin Recharge Demo

This is a front-end demo only. It does not process payments or recharge any account.

## Run
Open `index.html` in a browser.

## To make it production-ready
- Add a real backend and database.
- Use an authorized payment provider.
- Use an authorized recharge/API integration where permitted.
- Verify payment server-side.
- Never collect passwords, login codes, or OTPs.
- Add authentication, rate limiting, logging, and fraud controls.
